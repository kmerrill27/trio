#!python

# Starter code provided by Robert Keller
# modified by Kim Merrill
# Run "python gradual_insanity.py" and enter desired search algorithm
from bfs import bfs_solve
from id import id_solve
from astar import astar_solve
import sys

class Insanity_Problem:

    # A state is a tuple of tuples.
    # Each tuple represents one row of the puzzle.
 
    def __init__(self, start_state, goal_state):
        """ Insanity_Problem(start_state, goal_state) creates an instance of the problem """
        self.start_state = start_state
        self.goal_state = goal_state

    def start(self):
        """ returns the start state """
        return self.start_state

    def get_goal(self):
        """ returns the goal state """
        return self.goal_state

    def goal(self, state):
        """ returns True if the argument is the goal state """
        return state == self.goal_state

    def expand(self, state):
        """ returns a generator for the successors of state
            calling next() on the generator returns the successors
            one at a time, until there are no more, in which case
            None is returned """

        # convert the tuple of rows to list of rows for
        # transient modification
        state_as_list = list(state)

        # iterate by index, as we intend to modify the list

        for row_index in range(0, len(state_as_list)):

            # save the original row
            original_row = state_as_list[row_index]

            # replace the original row with a left rotation of it and yield
            state_as_list[row_index] = rotate_left(original_row)
            yield tuple(state_as_list)

            # replace the original row with a right rotation of it and yield
            state_as_list[row_index] = rotate_right(original_row)
            yield tuple(state_as_list)

            # restore the original row for subsequent modification
            state_as_list[row_index] = original_row

        # form a transposed version of the state, so we can treat columns as rows

        transposed = zip(*state)

        # iterate by index, as we intend to modify

        for row_index in range(0, len(transposed)):
            
            # save the original row (a column of the state)
            original_row = transposed[row_index]

            # rotate the row left and yield a new state by transposing
            transposed[row_index] = rotate_left(original_row)
            yield tuple(zip(*transposed))

            # rotate the row right and yield a new state by transposing
            transposed[row_index] = rotate_right(original_row)
            yield tuple(zip(*transposed))

            # restore the original row for further modification
            transposed[row_index] = original_row

        # signal that there are no further modifications
        yield None

def rotate_left(row):
    """ return a tuple that is the argument rotated one position left """
    return row[1:] + row[0:1]

def rotate_right(row):
    """ return a tuple that is the argument rotate one position right """
    return row[-1:] + row[0:-1]

def print_problem(id, problem):
    start = problem.start()
    goal = problem.get_goal()
    print id
    print "start:"
    for row in start:
        print row
    print "goal:"
    for row in goal:
        print row

def solve(alg, id, problem):
    """ Solve an instance of Insanity_Problem """

    if (alg == 1):
      print_problem(id, problem)
      bfs_solve(problem)
    elif (alg == 2):
      print_problem(id, problem)    
      id_solve(problem)
    elif (alg == 3):
      print_problem(id, problem)
      astar_solve(problem)
    # If user did not enter a 1, 2, or 3, do not run a search alg
    else:
      print "Invalid input"
      exit()

def test(alg):
    """ Test cases for gradual insanity """

    solve(alg, "2x2, 4 colors", Insanity_Problem(
          ((2,4),(3,1)),((1,2),(3,4))))
    
    solve(alg, "3x3, 3 colors", Insanity_Problem(
          ((2,3,1),(2,3,1),(1,2,3)),
          ((1,2,3),(1,2,3),(1,2,3))))

    solve(alg, "3x3, 2 colors", Insanity_Problem(
          ((2,1,1),(1,2,1),(1,1,2)), 
          ((1,2,2),(1,1,2),(1,1,1))))

    solve(alg, "4x4, 2 colors", Insanity_Problem(
          ((2,1,1,1),(1,2,1,1),(1,1,2,1),(1,1,1,2)),
          ((1,1,1,1),(1,2,2,1),(1,2,2,1),(1,1,1,1))))

    solve(alg, "5x5, 2 colors", Insanity_Problem(
          ((2,1,1,2,2),(2,2,2,1,2),(2,1,2,2,2),(1,2,2,2,2),(2,2,2,2,2)),
          ((1,2,2,2,1),(2,2,2,2,2),(2,2,1,2,2),(2,2,2,2,2),(1,2,2,2,1))))

    solve(alg, "3x3, 9 colors", Insanity_Problem(
          ((5,6,3),(9,8,2),(1,4,7)),
          ((1,2,3),(4,5,6),(7,8,9))))

    solve(alg, "4x4, 4 colors", Insanity_Problem(
          ((1,4,2,2),(2,3,3,3),(1,2,1,4),(4,4,3,1)),
          ((1,1,1,1),(2,2,2,2),(3,3,3,3),(4,4,4,4))))

    solve(alg, "6x6, 4 colors #1", Insanity_Problem(
          ((2,1,1,1,2,4),
           (1,1,1,2,2,2),
           (2,2,3,1,3,2),
           (2,3,3,3,4,4),
           (3,3,3,4,4,4),
           (3,1,1,4,4,4)),
          ((1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4))))

    solve(alg, "6x6, 4 colors #2", Insanity_Problem(
          ((2,1,1,1,2,4),
           (1,1,1,2,2,2),
           (2,2,3,1,3,2),
           (4,2,3,3,3,4),
           (3,3,3,4,4,4),
           (3,1,1,4,4,4)),
          ((1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4))))

    solve(alg, "6x6, 4 colors #3", Insanity_Problem(
          ((2,1,1,1,2,4),
           (1,1,3,2,2,2),
           (2,2,3,1,3,2),
           (4,2,3,3,3,4),
           (3,3,1,4,4,4),
           (3,1,1,4,4,4)),
          ((1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4))))

    solve(alg, "6x6, 4 colors #4", Insanity_Problem(
          ((2,1,1,4,2,4),
           (1,1,3,1,2,2),
           (2,2,3,2,3,2),
           (4,2,3,1,3,4),
           (3,3,1,3,4,4),
           (3,1,1,4,4,4)),
          ((1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (1,1,1,2,2,2),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4),
           (3,3,3,4,4,4))))

alg = input("Enter 1 for BFS, 2 for Iterative Deepening, or 3 for A*:")
test(alg)
