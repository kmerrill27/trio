#
# Gradual Insanity solver using BFS algorithm
# Kim Merrill
#

from node import *

def bfs_solve(problem):
    num_expansions = 0
    queue = [Node(problem.start(), 0, None)]
    # Continue searching while there are still nodes to be examined
    while queue != []:
        curr_node = queue.pop(0)
        # If search reached goal state, print solution path
        if problem.goal(curr_node.state):
            print "expansions: " + str(num_expansions)
            print "depth: " + str(curr_node.depth)
            curr_node.print_path()
            return
        # Generate all successors for current state
        successors = problem.expand(curr_node.state)
        num_expansions += 1
        next_state = successors.next()
        # Add successors to the end of queue to be examined
        while next_state != None:
            queue.append(Node(next_state, curr_node.depth + 1, curr_node))
            next_state = successors.next()
    return None
