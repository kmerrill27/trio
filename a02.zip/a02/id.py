#
# Gradual Insanity solver using iterative deepening algorithm
# Kim Merrill
#

num_expansions = 0
path = []

def id_solve(problem):
    for i in range(0, 25):
        result = dfs(problem, i)
	    # If alg returned because it found a solution, print path
        if result != -1:
            print_path(problem.start())
            reset()
            return
    # No solution was found before reaching the max depth limit
    reset()
    return None

def dfs(problem, cutoff):
    return dfs_aux(problem.start(), 0, problem, cutoff)

def dfs_aux(state, depth, problem, cutoff):
    global num_expansions, path
    is_cutoff = False
    # If search reached goal state, return
    if problem.goal(state):
        print "expansions: " + str(num_expansions)
        print "depth: " + str(depth)
        return state
    # If search reached depth limit, return
    elif depth >= cutoff:
        return -1
    else:
        # Generate all successors for current state
        successors = problem.expand(state)
        num_expansions += 1
        next_state = successors.next()
        while next_state != None:
            # Search down current path
            result = dfs_aux(next_state, depth+1, problem, cutoff)
            if result == -1:
                is_cutoff = True
            # If next_state is on the solution path, print it
            elif result != None:
                path.append(next_state)
                return result
            next_state = successors.next()
        if is_cutoff:
            return -1
        # Search fails if goal state not found and cutoff not reached
        else:
            return None

def print_path(start):
    i = 0
    path.append(start)
    path.reverse()
    for state in path:
        print "step " + str(i) + ":"
        i += 1
        for row in state:
            print row

def reset():
    global num_expansions, path
    num_expansions = 0
    path = []
