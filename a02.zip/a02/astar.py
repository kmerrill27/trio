#
# Gradual Insanity solver using A* algorithm
# Kim Merrill
#
# Line 41 becomes bottleneck if searching for a node in open_list bc heap
# does not support constant-time lookup. Instead of keeping an open and
# a closed list and then searching both, keeps a set of all seen nodes
# for fast lookup. Last step of alg that moves nodes from the closed list
# to the open list was not required, so the closed list is not needed.
#

import heapq, time
from node import Node

def astar_solve(problem):
    num_expansions = 0
    start_node = Node(problem.start(), 0, None)
    # Nodes to be evaluated, "keyed" by their cost
    open_list = [(0, start_node)]
    # Nodes already evaluated or seen
    seen_nodes = set([start_node])
    while open_list != []:
        compound_node = heapq.heappop(open_list)
        curr_cost = compound_node[0]
        curr_node = compound_node[1]
        # If search reached goal state, print solution path
        if problem.goal(curr_node.state):
            print "expansions: " + str(num_expansions)
            print "depth: " + str(curr_node.depth)
            curr_node.print_path()
            return
        # Generate all successors for current state
        successors = problem.expand(curr_node.state)
        num_expansions += 1
        next_state = successors.next()
        while next_state != None:
            # Estimate cost to reach goal from state
            next_cost = curr_node.depth + cost_estimate(next_state, problem.get_goal())
            next_node = Node(next_state, curr_node.depth + 1, curr_node)
            # If node has not already been seen, add it to list to be evaluated
            if next_node not in seen_nodes:
                heapq.heappush(open_list, (next_cost, next_node))
                seen_nodes.add(curr_node)
            next_state = successors.next()
    return None

# Takes the minimum of the number of wrong rows and the number of wrong cols
def cost_estimate(state, goal):
    wrong_rows = 0
    wrong_cols = 0
    # Count all rows that are the same between current and goal state
    for s_row, g_row in zip(list(state), goal):
        if s_row != g_row:
            wrong_rows += 1
    # Count all columns that are the same between current and goal state
    for s_col, g_col in zip(zip(*state), zip(*goal)):
        if s_col != g_col:
            wrong_cols += 1
    return min(wrong_rows, wrong_cols)
