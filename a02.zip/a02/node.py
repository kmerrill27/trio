#
# A Node is a state, its depth in the search tree,
# and its parent Node.
# Kim Merrill
#

class Node:

    def __init__(self, state, depth, parent):
        self.state = state
        self.depth = depth
        self.parent = parent

    def state(self):
        return self.state

    def depth(self):
        return self.depth

    def parent(self):
        return self.parent

    # Print all states in the path that leads to Node
    def print_path(self):
        i = 0
        # Traverse up the search tree while there are
        # still Nodes in the path
        while self.parent != None:
            self.parent.print_path()
            print "step " + str(self.depth) + ":"
            for row in self.state:
                print row
            return
        # Print start state
        print "step " + str(self.depth) + ":"
        for row in self.state:
            print row
